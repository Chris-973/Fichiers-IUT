public class Exo5 {

}
